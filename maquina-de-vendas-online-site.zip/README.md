# Máquina de Vendas Online — página de apresentação

## Publicar com GitHub Pages
1. Crie uma conta em https://github.com/ (se ainda não tiver).
2. Crie um repositório público chamado `maquina-de-vendas-online`.
3. Envie o arquivo `index.html` deste pacote para a raiz do repositório.
4. No GitHub, abra **Settings → Pages**.
5. Em **Build and deployment**, selecione **Deploy from a branch**.
6. Escolha a branch `main` e a pasta `/ (root)`, depois clique em **Save**.
7. Aguarde o GitHub Pages publicar. O endereço será exibido na mesma tela de Pages.

## Importante sobre pagamentos
A página exibe a chave Pix informada e explica que o pagamento não é confirmado automaticamente.
Ela não processa pagamentos nem libera o curso automaticamente. Para isso, conecte um checkout seguro
(por exemplo, o checkout da plataforma onde o curso será vendido) e configure a entrega do acesso.
Confira se a chave Pix está correta e se o destinatário exibido no banco é você antes de divulgar.
